package AppStartup;
import forms.ViewProduto;
/**
 *
 * @author hierro.melo
 */
public class AppStartup {
    public static void main(String[] args) {
       ViewProduto vrp = new ViewProduto();
        vrp.setVisible(true);
    }
    
}
